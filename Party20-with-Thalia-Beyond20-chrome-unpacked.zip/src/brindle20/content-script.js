// Brindle20 bridge: lets a regular HTML character sheet dispatch Beyond20 roll requests.
// It deliberately does NOT register the page as a custom VTT target; it only forwards
// messages from the page to the Beyond20 background worker, which then forwards to Roll20/FVTT.
(function () {
    const allowedActions = new Set(["roll", "rendered-roll", "hp-update", "conditions-update", "update-combat"]);

    function fire(name, payload) {
        document.dispatchEvent(new CustomEvent("Beyond20_" + name, { detail: [payload] }));
    }

    function ready() {
        fire("Brindle20Ready", {
            ok: true,
            extensionUrl: chrome.runtime.getURL(""),
            extensionVersion: chrome.runtime.getManifest().version
        });
    }

    document.addEventListener("Beyond20_SendMessage", (evt) => {
        const detail = evt.detail || [];
        const message = Array.isArray(detail) ? detail[0] : detail;
        if (!message || !allowedActions.has(message.action)) {
            fire("RollResult", { success: false, error: "Invalid or unsupported Beyond20 message.", request: message || null });
            return;
        }
        chrome.runtime.sendMessage(message, (response) => {
            if (chrome.runtime.lastError) {
                fire("RollResult", { success: false, error: chrome.runtime.lastError.message, request: message });
            } else {
                fire("RollResult", response || { success: true, request: message });
            }
        });
    }, false);

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", ready, { once: true });
    } else {
        ready();
    }
})();
