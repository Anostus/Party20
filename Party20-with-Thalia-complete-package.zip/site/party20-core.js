const ROLL = { NORMAL:0, DOUBLE:1, QUERY:2, ADV:3, DIS:4 };
const WHISPER = { NO:0, YES:1, QUERY:2, HIDE:3 };
let bridgeReady = false;
const $ = (id)=>document.getElementById(id);
function esc(s){return String(s ?? '').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function toast(msg, good=true){const t=$('toast'); if(!t) return; t.textContent=msg; t.className=good?'good':'bad'; t.style.display='block'; clearTimeout(t._timer); t._timer=setTimeout(()=>t.style.display='none',4200);}
function rollMode(){return Number($('roll-mode')?.value ?? 0)}
function whisper(){return Number($('whisper-mode')?.value ?? 0)}
function setStatus(ok){bridgeReady=ok; const s=$('bridge-status'); if(!s) return; s.classList.toggle('good',ok); s.classList.toggle('bad',!ok); s.textContent=ok?'Beyond20 bridge detected':'Beyond20 bridge not detected';}
document.addEventListener('Beyond20_Party20Ready',()=>setStatus(true));
document.addEventListener('Beyond20_Brindle20Ready',()=>setStatus(true));
document.addEventListener('Beyond20_RollResult',(e)=>{const r=(e.detail||[])[0]||{}; if(r.error) toast(r.error,false); else toast('Sent to '+((r.vtt||['VTT']).join(', ')),true)});
function requestBridgeReady(){ document.dispatchEvent(new CustomEvent('Beyond20_RequestParty20Ready')); }
let _bridgeProbeCount=0; const _bridgeProbe=setInterval(()=>{ if(bridgeReady || _bridgeProbeCount++ > 20) return clearInterval(_bridgeProbe); requestBridgeReady(); }, 250);
requestBridgeReady();
function send(request, character){
  if(!bridgeReady) toast('Beyond20 bridge not detected. Load the Party20 extension and open this page through localhost or GitHub Pages.',false);
  request.action='roll';
  request.character=request.character || character || window.PARTY20_CHARACTER || {name:'Party20 Character',type:'Character',settings:{}};
  request.advantage = request.advantage ?? rollMode();
  request.whisper = request.whisper ?? whisper();
  document.dispatchEvent(new CustomEvent('Beyond20_SendMessage',{detail:[request]}));
}
function characterFor(name,type='Character'){return {name, type, settings:{}}}
function traitReq(name, source, description, character){send({type:'trait', name, source, 'source-type':'Feature', description, advantage:ROLL.NORMAL}, character)}
function rollCheck(kind, data, character){
  if(kind==='initiative') return send({type:'initiative', initiative:data.modifier}, character);
  if(kind==='ability') return send({type:'ability', name:data.name, ability:data.ability||data.name, modifier:data.modifier}, character);
  if(kind==='save') return send({type:'saving-throw', name:data.name, ability:data.ability, modifier:data.modifier}, character);
  if(kind==='skill') return send({type:'skill', skill:data.name, ability:data.ability, modifier:data.modifier}, character);
}
function attackReq(a, character, prefix='', opts={}){
  send({type:'attack', name:prefix+a.name, 'to-hit':a.toHit, rollAttack:true, rollDamage:true, damages:[a.damage], 'damage-types':[a.type], 'critical-damages':[a.crit||a.damage?.replace(/\s*[+\-].*/, '')||''], 'critical-damage-types':[a.type], range:a.range||'', description:a.description||'', advantage:opts.advantage ?? undefined}, character);
}
function spellCard(s, character){send({type:'spell-card', name:s.name, 'level-school':s.level, 'casting-time':s.time, range:s.range, duration:s.duration, components:s.components, ritual:!!s.ritual, concentration:!!s.concentration, description:s.desc||s.description||'', advantage:ROLL.NORMAL}, character)}
function spellRoll(s, character){send({type:'spell-attack', name:s.name, 'level-school':s.level, 'casting-time':s.time, range:s.range, duration:s.duration, components:s.components, ritual:!!s.ritual, concentration:!!s.concentration, description:s.desc||'', rollAttack:!!s.toHit, 'to-hit':s.toHit, rollDamage:!!s.damage, damages:s.damage?[s.damage]:[], 'damage-types':s.type?[s.type]:[], 'critical-damages':s.crit?[s.crit]:[], 'critical-damage-types':s.type?[s.type]:[], 'save-dc':s.saveDC, 'save-ability':s.save}, character)}
function row(title, sub, buttons){return `<div class="row"><div><b>${esc(title)}</b>${sub?`<br><small>${esc(sub)}</small>`:''}</div><div class="actions">${buttons}</div></div>`}
function renderSheet(data){
  window.PARTY20_CHARACTER = characterFor(data.name);
  document.title = data.title || data.name;
  $('char-title').textContent = data.name;
  $('char-subtitle').textContent = data.subtitle || '';
  $('core-stats').innerHTML = data.core.map(x=>`<div><b>${esc(x.label)}</b><span>${esc(x.value)}</span></div>`).join('');
  $('core-buttons').innerHTML = (data.coreButtons||[]).map(k=>`<button data-trait="${esc(k)}" class="primary">${esc(data.traits[k]?.name||k)}</button>`).join('');
  $('abilities').innerHTML = data.abilities.map(a=>`<button data-check="ability" data-name="${esc(a.name)}" data-ability="${esc(a.name)}" data-modifier="${esc(a.modifier)}">${esc(a.name)} ${esc(a.score)} (${esc(a.modifier)})</button>`).join('');
  $('saves').innerHTML = data.saves.map(a=>`<button data-check="save" data-name="${esc(a.name)}" data-ability="${esc(a.ability)}" data-modifier="${esc(a.modifier)}">${esc(a.name)} ${esc(a.modifier)}</button>`).join('');
  $('skills').innerHTML = data.skills.map(a=>`<button data-check="skill" data-name="${esc(a.name)}" data-ability="${esc(a.ability)}" data-modifier="${esc(a.modifier)}">${esc(a.name)} ${esc(a.modifier)}</button>`).join('');
  $('attacks').innerHTML = data.attacks.map((a,i)=>row(a.name, `${a.toHit}; ${a.damage} ${a.type}; ${a.range||''}`, `<button data-attack="${i}">Roll</button>${a.advantageButton?`<button data-attack="${i}" data-adv="3">Adv</button>`:''}${a.disButton?`<button data-attack="${i}" data-adv="4">Dis</button>`:''}`)).join('');
  $('traits').innerHTML = Object.entries(data.traits).filter(([k,t])=>!data.coreButtons?.includes(k)).map(([k,t])=>row(t.name, t.source||'', `<button data-trait="${esc(k)}">Send</button>`)).join('');
  $('spells').innerHTML = (data.spells||[]).map((s,i)=>row(s.name, `${s.level||''}; ${s.time||''}; ${s.range||''}; ${s.duration||''}`, `<button data-spellcard="${i}">Card</button>${s.damage||s.toHit?`<button data-spellroll="${i}">Roll</button>`:''}`)).join('') || '<p class="muted">No spells or rituals on this sheet.</p>';
  $('equipment').textContent = data.equipment || '';
  renderSummons(data);
  document.body.addEventListener('click', ev=>{
    const b=ev.target.closest('button'); if(!b) return;
    if(b.dataset.roll==='initiative') return rollCheck('initiative',{modifier:data.initiative}, characterFor(data.name));
    if(b.dataset.check) return rollCheck(b.dataset.check,{name:b.dataset.name, ability:b.dataset.ability, modifier:b.dataset.modifier}, characterFor(data.name));
    if(b.dataset.attack) return attackReq(data.attacks[Number(b.dataset.attack)], characterFor(data.name), '', {advantage: b.dataset.adv?Number(b.dataset.adv):undefined});
    if(b.dataset.trait){const t=data.traits[b.dataset.trait]; return traitReq(t.name,t.source,t.description, characterFor(data.name));}
    if(b.dataset.spellcard) return spellCard(data.spells[Number(b.dataset.spellcard)], characterFor(data.name));
    if(b.dataset.spellroll) return spellRoll(data.spells[Number(b.dataset.spellroll)], characterFor(data.name));
    if(b.dataset.summonCard) return sendSummonCard(data, Number(b.dataset.summonCard));
    if(b.dataset.summonAttack) return sendSummonAttack(data, Number(b.dataset.summonAttack), false);
    if(b.dataset.summonMulti) return sendSummonAttack(data, Number(b.dataset.summonMulti), true);
    if(b.dataset.summonSkill) { const s=data.summons[Number(b.dataset.summonSkill)]; const skill=s.skills[b.dataset.skillName]; return rollCheck('skill',{name:`${s.name} ${b.dataset.skillName}`,ability:skill.ability,modifier:skill.modifier}, characterFor(s.name,'Creature')); }
  }, {once:false});
  const lvl=$('undead-level'); if(lvl) lvl.addEventListener('change',()=>renderSummons(data));
  setTimeout(()=>{if(!bridgeReady) toast('Bridge not detected yet. Use the Party20 extension and open this page from http://localhost or https://anostus.github.io/.',false)},1000);
}
function renderSummons(data){
  const box=$('summons'); if(!box) return;
  const summons=data.summons||[];
  const undeadLevelSelector = $('undead-level');
  if(undeadLevelSelector) undeadLevelSelector.closest('.summon-controls').style.display = summons.some(s=>s.kind==='undead')?'block':'none';
  box.innerHTML = summons.map((s,idx)=>{
    const d = summonDynamic(s);
    const skills = s.skills ? Object.keys(s.skills).map(k=>`<button data-summon-skill="${idx}" data-skill-name="${esc(k)}">${esc(k)}</button>`).join('') : '';
    const attackBtns = s.attack ? `<button data-summon-attack="${idx}">${esc(s.attack.name)}</button>${s.kind==='undead'?`<button data-summon-multi="${idx}">Multiattack</button>`:''}` : '';
    return `<div class="summon"><h3>${esc(s.name)}</h3><div class="meta">${esc(d.meta)}</div><div class="tags">${(s.tags||[]).map(t=>`<span class="tag">${esc(t)}</span>`).join('')}</div><p class="muted">${esc(d.short||s.short||'')}</p><div class="actions"><button data-summon-card="${idx}">Stat/Traits</button>${skills}${attackBtns}</div></div>`
  }).join('') || '<p class="muted">No summons or familiars listed.</p>';
}
function summonDynamic(s){
  if(s.kind==='undead'){
    const lvl=Number($('undead-level')?.value || 3);
    return {ac:11+lvl, hp:30+10*(lvl-3), multi:Math.floor(lvl/2), meta:`AC ${11+lvl}; HP ${30+10*(lvl-3)}; speed ${s.speed}; multiattack ${Math.floor(lvl/2)}; spell level ${lvl}`, short:s.short};
  }
  return {meta:s.meta||'', short:s.short};
}
function sendSummonCard(data, idx){
  const s=data.summons[idx]; const d=summonDynamic(s);
  let desc = s.description || '';
  if(s.kind==='undead'){
    desc = `Medium undead. ${d.meta}. STR 12 (+1), DEX 16 (+3), CON 15 (+2), INT 4 (-3), WIS 10 (+0), CHA 9 (-1). Damage immunities: necrotic, poison. Condition immunities: exhaustion, frightened, paralyzed, poisoned. Senses darkvision 60 ft, passive Perception 10. Languages: understands the languages ${data.name} speaks. Proficiency bonus equals summoner's. ${s.description||''}`;
  }
  traitReq(s.name, s.source||'Summon/Familiar', desc, characterFor(s.name,'Creature'));
}
function sendSummonAttack(data, idx, multi){
  const s=data.summons[idx]; if(!s.attack) return;
  const d=summonDynamic(s); let a={...s.attack};
  if(s.kind==='undead'){
    const lvl=Number($('undead-level')?.value || 3);
    a.damage = `${s.attack.base} + ${3+lvl}`;
    a.crit = s.attack.base;
  }
  const count=multi?(d.multi||1):1;
  for(let i=0;i<count;i++) setTimeout(()=>attackReq(a, characterFor(s.name,'Creature'), count>1?`${i+1}/${count} `:''), i*180);
}