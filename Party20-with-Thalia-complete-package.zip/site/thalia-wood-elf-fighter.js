const THALIA = {
  name:'Thalia', title:'Thalia — Level 5 Battle Master Fighter', subtitle:'Level 5 Wood Elf Fighter — Battle Master · Officer · 110 years old', initiative:'+1',
  core:[
    {label:'AC',value:'17 noted · 19 with shield noted'},
    {label:'HP',value:'54 with Tough (44 base +10)'},
    {label:'Hit Dice',value:'5d10'},
    {label:'Speed',value:'35 ft'},
    {label:'Prof',value:'+3'},
    {label:'Passive Perception',value:'13'},
    {label:'Superiority Dice',value:'4d8'},
    {label:'Maneuver DC',value:'14'}
  ],
  abilities:[['STR',17,'+3'],['DEX',12,'+1'],['CON',15,'+2'],['INT',8,'-1'],['WIS',10,'+0'],['CHA',13,'+1']].map(([name,score,modifier])=>({name,score,modifier})),
  saves:[['Strength','STR','+6'],['Dexterity','DEX','+1'],['Constitution','CON','+5'],['Intelligence','INT','-1'],['Wisdom','WIS','+0'],['Charisma','CHA','+1']].map(([name,ability,modifier])=>({name,ability,modifier})),
  skills:[
    ['Athletics','STR','+6'],['Acrobatics','DEX','+1'],['Sleight of Hand','DEX','+1'],['Stealth','DEX','+1'],
    ['Arcana','INT','-1'],['History','INT','-1'],['Investigation','INT','-1'],['Nature','INT','-1'],['Religion','INT','-1'],
    ['Animal Handling','WIS','+0'],['Insight','WIS','+3'],['Medicine','WIS','+0'],['Perception','WIS','+3'],['Survival','WIS','+3'],
    ['Deception','CHA','+1'],['Intimidation','CHA','+4'],['Performance','CHA','+1'],['Persuasion','CHA','+1']
  ].map(([name,ability,modifier])=>({name,ability,modifier})),
  coreButtons:['summary','actionSurge','secondWind','combatSuperiority'],
  traits:{
    summary:{name:'Core Summary',source:'Character Sheet',description:'Thalia is a level 5 wood elf fighter, Battle Master archetype, officer background. Proficiency +3. AC 17 noted on the sheet, with 19 noted beside the shield. HP is recorded here as 54 with Tough (44 base fighter HP + 10 from Tough); the paper notes also track Second Wind separately. Speed 35 ft. Initiative +1. Passive Perception 13. Languages: Common and Elvish.'},
    actionSurge:{name:'Action Surge',source:'Fighter 2',description:'Once per short or long rest, Thalia can take one additional action on top of her regular action and possible bonus action on her turn.'},
    secondWind:{name:'Second Wind',source:'Fighter 1',description:'Bonus action. Once per short or long rest, Thalia regains 1d10 + 5 hit points.'},
    dueling:{name:'Fighting Style: Dueling',source:'Fighter 1',description:'When Thalia wields a melee weapon in one hand and no other weapons, she gains a +2 bonus to damage rolls with that weapon. The lance and longsword damage entries on this sheet include the +2 damage note from the paper.'},
    extraAttack:{name:'Extra Attack',source:'Fighter 5',description:'Thalia can attack twice, instead of once, whenever she takes the Attack action on her turn.'},
    combatSuperiority:{name:'Combat Superiority',source:'Battle Master 3',description:'Thalia has 4 superiority dice, which are d8s. Superiority dice are expended to fuel Battle Master maneuvers and are regained after a short or long rest. Maneuver save DC: 14. The paper note says each attack can be enhanced by only one maneuver.'},
    maneuverPlaceholder:{name:'Maneuvers — to fill in',source:'Battle Master 3',description:'The notes say the specific maneuvers were not written on the sheet yet. Add Thalia’s chosen Battle Master maneuvers here when known. One maneuver can be applied per attack. If a maneuver forces a save, use DC 14.'},
    studentOfWar:{name:'Student of War',source:'Battle Master 3',description:'Thalia gains proficiency with one type of artisan’s tools of her choice. The paper leaves the chosen tool open.'},
    savageAttacker:{name:'Savage Attacker',source:'Feat/Combat Note',description:'Once per turn when Thalia rolls damage for a melee weapon attack, she can reroll the weapon’s damage dice and use either total. The notes call out this as strongest on high-damage single hits, especially the lance.'},
    tough:{name:'Tough',source:'Feat',description:'Thalia’s hit point maximum increases by 2 per level. At level 5, this is +10 HP. This sheet records HP as 54 using that adjustment.'},
    darkvision:{name:'Darkvision',source:'Elf',description:'Thalia can see in dim light within 60 feet as if it were bright light, and in darkness as if it were dim light. She cannot discern color in darkness, only shades of gray.'},
    feyAncestry:{name:'Fey Ancestry',source:'Elf',description:'Thalia has advantage on saving throws against being charmed, and magic cannot put her to sleep.'},
    trance:{name:'Trance',source:'Elf',description:'Thalia does not need to sleep. She meditates for 4 hours and gains the same benefit a human gets from 8 hours of sleep.'},
    keenSenses:{name:'Keen Senses',source:'Elf',description:'Thalia is proficient in the Perception skill.'},
    elfWeaponTraining:{name:'Elf Weapon Training',source:'Wood Elf',description:'Thalia is proficient with longsword, shortsword, shortbow, and longbow.'},
    fleetOfFoot:{name:'Fleet of Foot',source:'Wood Elf',description:'Thalia’s base walking speed increases to 35 feet.'},
    maskOfTheWild:{name:'Mask of the Wild',source:'Wood Elf',description:'Thalia can attempt to hide even when only lightly obscured by foliage, heavy rain, falling snow, mist, and other natural phenomena.'},
    officer:{name:'Officer Background',source:'Background',description:'Background noted as Officer. Personality: “I can stare down a hell hound without flinching.” Ideal: Might. Bond: “I’ll never forget the crushing defeat my company suffered or the enemies who dealt it.” Flaw: “I have little respect for anyone who is not a proven warrior.”'},
    proficiencies:{name:'Proficiencies',source:'Sheet Notes',description:'Armor: all armor and shields. Weapons: simple and martial weapons. Saving throws: Strength and Constitution. Tools/other proficiencies noted: cards and land vehicles. Languages: Common and Elvish.'}
  },
  attacks:[
    {name:'Lance',toHit:'+6',damage:'1d12 + 5',crit:'1d12',type:'Piercing',range:'Reach 10 ft',advantageButton:true,description:'Damage uses Strength plus Dueling as noted. Lance has special handling at many tables: disadvantage against targets within 5 ft; one-handed while mounted, two-handed when not mounted.'},
    {name:'Longsword',toHit:'+6',damage:'1d8 + 5',crit:'1d8',type:'Slashing',range:'5 ft',advantageButton:true,description:'One-handed longsword damage with Dueling included.'},
    {name:'Handaxe',toHit:'+5',damage:'1d6 + 3',crit:'1d6',type:'Slashing',range:'5 ft / 20/60 ft',advantageButton:true,description:'Uses the handwritten attack value from the sheet. If recalculating strictly from Strength + proficiency, attack bonus may be +6.'},
    {name:'Second Wind',toHit:'',damage:'1d10 + 5',crit:'1d10',type:'Healing',range:'Self',description:'This is healing, not an attack. Use the roll result as regained HP once per short or long rest.'},
    {name:'Superiority Die',toHit:'',damage:'1d8',crit:'1d8',type:'Maneuver die',range:'Self',description:'Roll one d8 superiority die for a Battle Master maneuver, then apply the maneuver text manually.'}
  ],
  spells:[],
  equipment:`Weapons: lance, longsword, two handaxes.
Armor and shield: chain mail, shield.
Adventuring gear: dungeoneer’s pack.
Officer/background gear: insignia of rank, trophy taken from a fallen enemy (piece of banner), deck of cards, common clothes, pouch with coin noted as 10 gp and 2 gp on the equipment page.
Other notes: cards and land vehicles proficiency; Common and Elvish languages.
Money notes visible on the sheet include 27 gp and a separate calculation/circled amount; these are left as notes rather than an authoritative total.`,
  summons:[]
};
renderSheet(THALIA);
