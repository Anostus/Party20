# Party20 character sheets and Beyond20 bridge

This package contains three static character sheets and modified Beyond20 extension builds.

## Sheets
- `site/brindle-duskhorn.html` — Brindle Duskhorn, level 6 satyr bladesinger.
- `site/tiny-halfling-barbarian.html` — Tiny, level 6 halfling barbarian.
- `site/thalia-wood-elf-fighter.html` — Thalia, level 5 wood elf Battle Master fighter.
- `site/index.html` — landing page with links to all three.
- `*-standalone.html` files inline the CSS and sheet logic, but still need to be opened from localhost or GitHub Pages for the browser extension to inject cleanly.

## Local hosting
From the `site/` directory:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000/` in the browser where the Party20 extension is loaded.

## GitHub Pages hosting
You can publish the contents of `site/` to a repo/page under `https://anostus.github.io/...`. The extension content script is permitted on that host.

## Extension install
Chrome/Edge: load `extension-chrome/` as an unpacked extension in Developer Mode.

Firefox: load `extension-firefox/manifest.json` as a temporary add-on from `about:debugging`. For a permanent Firefox install, the add-on must be signed by Mozilla.

Keep Roll20 open in another tab before clicking rolls. Disable the original Beyond20 extension while testing to avoid duplicate roll forwarding.

## Thalia notes
Thalia was entered as a level 5 wood elf Battle Master fighter from the provided photos. Her maneuvers were not written on the sheet, so the sheet includes the 4d8 superiority dice and DC 14 plus a placeholder trait for maneuvers. HP is recorded as 54 using the Tough note (44 base fighter HP + 10 from Tough). If your table is using the handwritten HP box differently, edit `site/thalia-wood-elf-fighter.js`.
